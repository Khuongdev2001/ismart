<?php
/* get date now */
function get_date_now(){
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    return date("Y-m-d H:i:s");
}