<!DOCTYPE html>
<html>

<head>
    <title>Quản lý ISMART</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="public/css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="public/css/reset.css" rel="stylesheet" type="text/css" />
    <link href="public/css/font-awesome/css/all.css" rel="stylesheet" type="text/css" />
    <link href="public/css/style.css" rel="stylesheet" type="text/css" />
    <link href="public/css/responsive.css" rel="stylesheet" type="text/css" />
    <script src="public/js/jquery-3.5.1.min.js" type="text/javascript"></script>
    <script src="public/js/bootstrap/popper.min.js"></script>
    <script src="public/js/bootstrap/bootstrap.min.js" type="text/javascript"></script>
    <script src="public/js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
    <script src="public/js/main.js" type="text/javascript"></script>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div class="wp-inner clearfix">
                    <button class="fas fa-bars show" id="btn-menu"></button>
                    <a href="<?php echo base_url("?mod=dashboard"); ?>" title="" id="logo" class="">ADMIN</a>
                </div>
            </div>