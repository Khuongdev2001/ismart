<?php


function str_limit($string, $limit = -1)
{
    return $string;
}
