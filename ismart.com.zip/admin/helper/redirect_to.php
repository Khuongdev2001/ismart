<?php
function redirect_to($url){
    header("location:{$url}");
}